UPDATE NOTES
- Replace db_config.php credentials with your MySQL username & password.
- Run the SQL in the original instructions to create the database and contacts table.
- Replace the placeholder images in /images with your real photos.
- Sukumar_Resume.pdf is not included; add your resume PDF to the project root if you want the Download Resume link to work.
- To view the site, put the folder on a PHP-enabled web server and visit index.html.
