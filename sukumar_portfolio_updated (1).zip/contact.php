<?php
// contact.php
header('Content-Type: text/html; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo "Method not allowed";
    exit;
}

function clean($v) {
    return trim(filter_var($v, FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES));
}

$name = isset($_POST['name']) ? clean($_POST['name']) : '';
$email = isset($_POST['email']) ? filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) : '';
$phone = isset($_POST['phone']) ? clean($_POST['phone']) : '';
$message = isset($_POST['message']) ? clean($_POST['message']) : '';

$errors = [];
if (strlen($name) < 2) $errors[] = "Please enter your name.";
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Please enter a valid email.";
if (strlen($message) < 5) $errors[] = "Please enter a message.";

if (!empty($errors)) {
    echo "<h2>Following errors occurred:</h2><ul>";
    foreach ($errors as $err) {
        echo "<li>" . htmlspecialchars($err) . "</li>";
    }
    echo "</ul><p><a href=\"index.html\">Back to site</a></p>";
    exit;
}

require_once 'db_config.php';

try {
    $stmt = $pdo->prepare(\"INSERT INTO contacts (name, email, phone, message, created_at) VALUES (:name, :email, :phone, :message, NOW())\");
    $stmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':phone' => $phone,
        ':message' => $message,
    ]);

    echo \"<h2>Thank you, \" . htmlspecialchars($name) . \"!</h2><p>Your message has been sent successfully. I will get back to you soon.</p>\";
    echo \"<p><a href=\\\"index.html\\\">Back to portfolio</a></p>\";
} catch (Exception $e) {
    error_log(\"Contact insert error: \" . $e->getMessage());
    http_response_code(500);
    echo \"An error occurred while saving your message. Please try again later.\";
}
?>