<?php
// db_config.php
// Update these with your MySQL credentials
$db_host = 'localhost';
$db_name = 'sukumar_portfolio';
$db_user = 'your_db_user';
$db_pass = 'your_db_password';

$dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    echo "Database connection failed.";
    error_log("DB connect error: " . $e->getMessage());
    exit;
}
?>